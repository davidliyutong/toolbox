# zsh_reload plugin

**This plugin is deprecated.** Use `omz reload` or `exec zsh` instead.
