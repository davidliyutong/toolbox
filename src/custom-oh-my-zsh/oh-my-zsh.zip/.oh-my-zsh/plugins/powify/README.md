# powify plugin

This plugin adds autocompletion for [powify](https://github.com/sethvargo/powify),
an easy-to-use wrapper for Basecamp's [pow](https://github.com/basecamp/pow).

To use it, add powify to the plugins array of your zshrc file:

```sh
plugins=(... powify)
```
