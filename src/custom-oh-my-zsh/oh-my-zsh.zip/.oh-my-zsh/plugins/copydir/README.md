# copydir plugin

Copies the path of your current folder to the system clipboard.

To use, add `copydir` to your plugins array:
```
plugins=(... copydir)
```

Then use the command `copydir` to copy the $PWD.
